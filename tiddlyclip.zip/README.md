tiddlyclip
==========
# Introduction

tiddlyclip is an extension for Mozilla Firefox and google chrome that enables clips of webpages to be inserted in a TiddlyWiki. 
For installation and configuations see the project documentation at:
http://tiddlyclip.tiddlyspot.com
