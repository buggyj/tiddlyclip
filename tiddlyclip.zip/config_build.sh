#!/bin/bash

# Build config for the build script, build.sh. Look there for more info.

APP_NAME=tiddlyclip
CHROME_PROVIDERS="content locale skin packages"
CLEAN_UP=1
ROOT_FILES="readme.txt"
ROOT_DIRS= 
BEFORE_BUILD=
AFTER_BUILD=
